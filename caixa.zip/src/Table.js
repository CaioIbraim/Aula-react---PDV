import {
    TableBuilder,
    TableBuilderColumn,
  } from 'baseui/table-semantic';
  
export default  (props) =>{

    return (
        <>
        <TableBuilder data={props.listaProduto}>
      <TableBuilderColumn header="#COD">
        {row =>row.id}
      </TableBuilderColumn>
      <TableBuilderColumn header="Produto">
        {row =>row.title}
      </TableBuilderColumn>
      <TableBuilderColumn header="Preço" numeric>
        {row => row.price.toLocaleString('pt-br',{style: 'currency', currency: 'BRL'})}
      </TableBuilderColumn>
    </TableBuilder>
        </>
    )

}