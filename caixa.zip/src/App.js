import { useState, useEffect } from 'react';
import {Client as Styletron} from 'styletron-engine-atomic';
import {Provider as StyletronProvider} from 'styletron-react';
import {LightTheme, BaseProvider, styled} from 'baseui';
import { FormControl } from "baseui/form-control";
import { Input } from "baseui/input";
import {StyledLink as Link} from 'baseui/link';
import {FlexGrid, FlexGridItem} from 'baseui/flex-grid';
import {Avatar} from 'baseui/avatar';
import {
  Delete,
  Search,
  Plus,
  CheckIndeterminate,
} from "baseui/icon";

import {
  HeadingXXLarge,
  HeadingXLarge,
  HeadingLarge,
  HeadingMedium,
  HeadingSmall,
  HeadingXSmall,
} from 'baseui/typography';
import { ButtonGroup } from "baseui/button-group";
import { Button } from "baseui/button";



import  Nav  from "./Nav"
import Table from "./Table"

const engine = new Styletron();
const itemProps = {
  backgroundColor: 'white',
  height: 'scale1000',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
};


function App() {

const [codigo, setCodigo] = useState('')
const [total, setTotal] = useState(0)
const [listaProduto, setListaProduto] = useState([])

useEffect(()=>{ 
  if(listaProduto.length > 0) {
    setTotal( listaProduto.map(item =>item.price).reduce(function(soma, i) {
      return soma + i;
    }) )
  }
},[listaProduto])

const handleGetProduto = async () => {
  if(codigo != ''){
    await fetch(`https://fakestoreapi.com/products/${codigo}`)
              .then(res=>res.json())
              .then(json=> setListaProduto([...listaProduto, json]))
              .then( _ => setCodigo(''))
  }
}

  return (
    <StyletronProvider value={engine}>
      <BaseProvider theme={LightTheme}>


         <FlexGrid
            flexGridColumnCount={3}
            flexGridColumnGap="scale800"
            flexGridRowGap="scale800"
          >
            <FlexGridItem {...itemProps}>
        
              <Avatar
                name="Logo"
                size="64px"
                src={`/imagem1.jpg`}
                key={1}
              />
        
        </FlexGridItem>
          </FlexGrid>
        
          {/* Input para buscar o produto */} 
          <Nav/>



        


          <FormControl label={() => "Código do produto"} caption={() => "Digite o código do produto para realizar a venda"}>
            <Input  value={codigo} onChange={e => setCodigo(e.target.value)} placeholder="Código do produto"  />
          </FormControl>

          <FormControl>
            <ButtonGroup>
              <Button onClick={e => handleGetProduto()} > <Search/> </Button>
              <Button> <CheckIndeterminate/> </Button>
              <Button> <Plus/> </Button>
            </ButtonGroup>
          </FormControl>


          <HeadingMedium>Total a pagar : {total.toLocaleString('pt-br',{style: 'currency', currency: 'BRL'})}</HeadingMedium>

            { listaProduto.length > 0 ?
                <Table listaProduto={listaProduto}/>
                  
            : null

            }
     



      </BaseProvider>
    </StyletronProvider>
  );
}

export default App;
