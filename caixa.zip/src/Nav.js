import * as React from "react";
import {
    AppNavBar,
    setItemActive
} from "baseui/app-nav-bar";
import {
    ChevronDown,
    Delete,
    Overflow,
    Upload
} from "baseui/icon";

export default () => {
    const [mainItems, setMainItems] = React.useState([

        { active: true, icon: Upload, label: "Venda" },
        { icon: Upload, label: "Pedidos" },
        {

            icon: ChevronDown,
            label: "Estoque",
            navExitIcon: Delete,
            children: [
                { icon: Upload, label: "Secondary A" },
                { icon: Upload, label: "Secondary B" }
            ]
        }
    ]);
    return ( < AppNavBar title = "PDV - @devcaioibraim"
        mainItems = { mainItems }
        onMainItemSelect = {
            item => {
                setMainItems(prev => setItemActive(prev, item));
            }
        }
        username = "Caio Ibraim"
        usernameSubtitle = "5 Stars"
        userItems = {
            [
                { icon: Overflow, label: "Atendente" }
            ]
        }
        onUserItemSelect = { item => console.log(item) }
        />
    );
}